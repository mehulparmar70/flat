
<div class="modal fade exampleModal" id="exampleModal" tabindex="-1" role="dialog" 
aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
      
    <h5 class="text-dark"><cite title="Client Name" class="card-client"></cite></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">

      <figure>

  <blockquote class="blockquote">
    <p class = "short-description"></p>
  </blockquote>


  <img class="card-img-top" src="" alt="Card image cap">
  
  <div class="col-sm-12">

  </div>


</figure>


		</div>
      </div>
    </div>
</div>

<!-- modal 2 -->

<div class="modal fade exampleModal" id="exampleModal2" tabindex="-1" role="dialog" 
aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
      
    <h5 class="text-dark"><cite title="Client Name" class="card-client"></cite></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">

      <figure>

  <blockquote class="blockquote">
    <p class = "short-description"></p>
  </blockquote>

  <img class="card-img-top" src="" alt="Card image cap">
  
  <div class="col-sm-12 video_block_popup">

  </div>


</figure>


		</div>
      </div>
    </div>
</div>