
<button type="button" class="btn btn-default"  id="btn-media-modal" data-toggle="modal" data-target="#modal-xl">
    <i class="fa fa-upload"></i> Upload Media</button>
    
          <div class="modal fade" id="modal-xl">
            <div class="modal-dialog modal-xl">
              <div class="modal-content">
    
                <div class="modal-header">
                  <h4 class="modal-title">Upload Multiple Images</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
    
                       <div class="modal-body media-modal-body"  id="media-body">
                          <div class="col-md-12">
                    
                            <div id="multipleImageUpload">
                                        
                            </div>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
    
            </div>	
                          