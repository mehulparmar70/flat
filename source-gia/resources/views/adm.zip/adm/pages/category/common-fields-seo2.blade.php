
                  <div class="col-sm-12 row mt-4">
                      <div class="col-sm-6">
                        <label  class="text-danger" class="text-danger" for="search_index">Allow search engines to show this Page in search results?</label>
                        <select class="form-control" name="search_index">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                      
                      <div class="col-sm-6">
                        <label  class="text-danger" class="text-danger" for="search_follow">Follow links on this Page?</label>
                        <select class="form-control" name="search_follow">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                    </div>

                    <div class="col-sm-12">
                      <label  class="text-danger" for="canonical_url">Canonical URL</label>
                      <input type="text" class="form-control" name="canonical_url" 
                        placeholder="Canonical URL" >
                      <span class="text-danger"></span>
                    </div>
